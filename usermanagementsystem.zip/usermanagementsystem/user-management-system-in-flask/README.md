# user-management-system-in-flask
this is complete user management system in flask with admin panel
# download
1. get clone https://github.com/hilalahmad32/user-management-system-in-flask.git
2. make venv in your directory 'python -m venv venv"
3. active your venv "in mac and linux 'source venv/Script/activate' and in window 'venv/Script/activate.bat'"
4. install pip install flask flask-session flask-sqlalchemy flask-bcrypt
5. and run this in your terminal python main.py
6. and enjoy the code
